(function () {
  'use strict';

  angular
    .module('dtm.authenticate', [
      'dtm.authenticate.controllers',
      'dtm.authenticate.services',
    ]);



  angular
    .module('dtm.authenticate.controllers',[]);

  angular
   .module('dtm.authenticate.services',[]);

})();
