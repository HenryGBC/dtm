(function () {
  'use strict';

  angular
    .module('dtm.profiles', [
      'dtm.profiles.controllers',
      'dtm.profiles.services',
    ]);



  angular
    .module('dtm.profiles.controllers',[]);

  angular
   .module('dtm.profiles.services',[]);

})();
